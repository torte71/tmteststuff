rm ~/printer_data/gcodes/plr -rf
