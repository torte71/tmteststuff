#!/bin/bash


#enable the control of the supper capacitor,GPIO3_A4
if [ -d /sys/class/gpio/gpio100 ]
then
        echo out > /sys/class/gpio/gpio100/direction
        echo 0 > /sys/class/gpio/gpio100/value
else
        echo 100 > /sys/class/gpio/export
        echo out > /sys/class/gpio/gpio100/direction
        echo 0 > /sys/class/gpio/gpio100/value
fi

#power-off signal,gpio85(GPIO2_C5)
if [ -d /sys/class/gpio/gpio85 ]
then
        echo in > /sys/class/gpio/gpio85/direction
else
        echo 85 > /sys/class/gpio/export
        echo in > /sys/class/gpio/gpio85/direction
fi

while :
do
        #level=`cat /sys/class/gpio/gpio85/value` #Detect the power-off signal,gpio85(GPIO1_B2)
        #echo "gpio:$((level))"
        if [ "$level" = 1 ]
        then		
			sync
#           shutdown -h now

        fi
        sync
        sleep 2
done