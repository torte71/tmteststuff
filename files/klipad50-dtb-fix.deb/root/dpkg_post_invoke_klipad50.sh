#!/bin/bash
APTPID=$( ps -ho ppid "${PPID}" )
APTCMD=$( ps -ho args ${APTPID} )
DTBDIR=/boot/dtb/rockchip
DTBFILE=$DTBDIR/rk3328-mkspi.dtb
DTBKLIPAD=/root/rk3328-mkspi-klipad50.dtb

if echo $APTCMD|grep -q " \(install\|purge\|autopurge\|remove\|autoremove\) .* linux-dtb-" ; then
	echo Replacing DTB file
	[ -e $DTBFILE ] && mv $DTBFILE $DTBFILE.$(date +"%y%m%d_%H%M%S")
	cp $DTBKLIPAD $DTBFILE
fi
